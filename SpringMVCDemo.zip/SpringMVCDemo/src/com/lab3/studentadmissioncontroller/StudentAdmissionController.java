package com.lab3.studentadmissioncontroller;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.Student;

@Controller
@RequestMapping("/admission")
public class StudentAdmissionController {
	@RequestMapping(
			value="",
			method=RequestMethod.GET
			)
	protected ModelAndView getForm(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		ModelAndView mav = new ModelAndView("admission-form");

		return mav;
	}
	
//	@RequestMapping(
//			value="/success-admission-form",
//			method=RequestMethod.POST
//			)
//	protected ModelAndView getSuccess(
//			@RequestParam("studentName") String name,
//			@RequestParam("studentHobby") String hobby
//			) throws Exception {
//		ModelAndView mav = new ModelAndView("admission-success");
//		mav.addObject("studentHobby", hobby);
//		mav.addObject("studentName", name);
//
//		return mav;
//	}
	
//	@RequestMapping(
//			value="/success-admission-form",
//			method=RequestMethod.POST
//			)
//	protected ModelAndView getSuccess(
//			@RequestParam Map<String, String> student
//			) throws Exception {
//		ModelAndView mav = new ModelAndView("admission-success");
//		String name = student.get("studentName");
//		String hobby = student.get("studentHobby");
//		mav.addObject("studentHobby", hobby);
//		mav.addObject("studentName", name);
//
//		return mav;
//	}
	
//	@RequestMapping(
//			value="/success-admission-form",
//			method=RequestMethod.POST
//			)
//	protected ModelAndView getSuccess(
//			@RequestParam Map<String, String> student
//			) throws Exception {
//		ModelAndView mav = new ModelAndView("admission-success");
//		Student stud = new Student();
//		stud.setStudentName(student.get("studentName"));
//		stud.setStudentHobby(student.get("studentHobby"));
//		
//		mav.addObject("stud", stud);
//
//		return mav;
//	}
	
	@RequestMapping(
			value="/success-admission-form",
			method=RequestMethod.POST
			)
	protected ModelAndView getSuccess(
			@Valid @ModelAttribute("stud") Student stud,
			BindingResult result
			) throws Exception {
		
		if(result.hasErrors()) {
			ModelAndView mav = new ModelAndView("admission-form");
			return mav;
		}
		
		ModelAndView mav = new ModelAndView("admission-success");

		return mav;
	}
	
	@ModelAttribute
	protected void setHeader(Model model) {
		model.addAttribute("cheader", "This is the header!");
	}
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
		binder.registerCustomEditor(Date.class, "studentDOB", new CustomDateEditor(sdf, false));
	}
}
