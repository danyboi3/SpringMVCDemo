package com.lab2.hellocontroller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

@Controller
public class HelloController {
	@RequestMapping("/hello")
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		ModelAndView mav = new ModelAndView("hello-page");
		mav.addObject("welcome", "Hi User, welcome to the first Spring MVC Application");

		return mav;
	}

	@RequestMapping("/hi")
	protected ModelAndView hiRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		ModelAndView mav = new ModelAndView("hello-page");
		mav.addObject("welcome", "Hi!!!! wavy");

		return mav;
	}
	
/*	@RequestMapping("/welcome/{country}/{user}")
	protected ModelAndView welcomeRequest(@PathVariable("country") String country, @PathVariable("user") String user) 
			throws Exception {

		ModelAndView mav = new ModelAndView("hello-page");
		mav.addObject("welcome", "Welcome " + user + " to " + country);

		return mav;

	}
*/	
	@RequestMapping("/welcome/{country}/{user}")
	protected ModelAndView welcomeRequest(@PathVariable Map<String, String> pathVars) 
			throws Exception {

		String user = pathVars.get("user");
		String country = pathVars.get("country");
		
		ModelAndView mav = new ModelAndView("hello-page");
		mav.addObject("welcome", "Welcome " + user + " to " + country);

		return mav;

	}

}
 